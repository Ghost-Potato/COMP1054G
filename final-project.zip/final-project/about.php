<!--About page: PUBLIC
* further in-depth history about kitten mittens
* aside that includes the original kitten mittens video
* -->
<?php
    //global header
    include 'templates/header.php';
    //title and description variables
    $title = "Kitten Mittens Login";
    $description = "The login page of the Kitten Mittens website";
?>
        <section class="history">
            <h3>Story Behind Kitten Mittons</h3>
            <p>Kitten Mittons started as a way to protect sensitive paws and reduce the noise cats make when playing around the house. We used local wool and hand knit the mittens ourselves, with an emphasis on quality. Since then, we have become the one-stop-shop for feline apparel across the country. We never forgot our humble beginnings and have ensured all products are handmade to the highest standard. We welcome all cat connoisseurs to join the Kitten Mittons Club! </p>
        </section>
        <aside class="founder-video">
            <h4>The Video That Started It All</h4>
            <iframe width="420" height="315"
                    src="https://www.youtube.com/watch?v=22O6Nmjt-mw">
            </iframe>
        </aside>
<?php
    //global footer
    include 'templates/footer.php';
?>