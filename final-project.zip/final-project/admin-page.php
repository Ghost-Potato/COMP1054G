<!--Admin page: RESTRICTED
* display registered users and admins,
* update/delete registered users-->
<?php
    //global header
    include 'templates/header.php';
    //title and description variables
    $title = "Kitten Mittens Login";
    $description = "The admin page of the Kitten Mittens website";

    //restricting page and checking for admin status
    session_start();
    if(!isset($_SESSION['user_id'])){
        //redirecting back to login page if variables are empty or do not match admin_id
        header('Location: login.php');
        exit();
    }else{
        //constructing the page and table to display all registered users
        //1.Connect to database with require_once
        require_once 'database.php';
        //2.Run the SQL query to select all users from registeredusers and store results
        $sql = "SELECT * FROM registeredusers";
        $result = $connection -> query($sql);
        //creating a table with echo and html
        echo "<section class='registered_users'>";
        echo "<h2>Registered Users</h2>";
        echo "<table class='registered_users_table'>
            <thead>
                <tr>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Username</th>
                    <th>Action</th>
                 <tr>
            </thead>"; //header for the table
        //using a foreach loop to run through database and append each stored record to the table
        foreach($result as $row){
            echo "<tr>
                <td>" .$row['firstName']. "</td>
                <td>" .$row['lastName']. "</td>
                <td>" .$row['email']. "</td>
                <td>" .$row['username']. "</td>
                <td><button id='update-user'>Update</button> <button id='delete-user'>Delete</button></td>
                </tr>";
        }
                
    }
    //closing the table
    echo "</table>";
    echo "</section>";





    //closing the connection for security
    $connection = null;
    //global footer
    include 'templates/footer.php';
?>