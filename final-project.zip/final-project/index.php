<?php
    //title and description variables
    $title = "Kitten Mittons";
    $description = "The index page of the Kitten Mittons website";
    //global header
    require 'templates/header.php';
?>
<!--body-->
<main>
    <div class="masthead-mask">
        <section class="desktop-masthead">
            <h2>The Original Kitten Mittons</h2>
            <img src="images/orange-with-mittens.jpg" alt="orange cat with red mittens">
        </section>
    </div>
    <section class="products">
        <h3>Most Popular Products</h3>
        <div class="product-cards">
            <div id="product-card-1">
                <img src="images/Frisco-Fleece.jpg" alt="Fleece Sweater">
                <h4 class="productName">Fleece Sweater</h4>
                <p class="price">$44.99</p>
                <label for="size-1"></label>
                <select id="size-1">
                    <option class="size">Small</option>
                    <option class="size">Medium</option>
                    <option class="size">Large</option>
                </select>
                <p>Keep your cat nice and cozy during winter with this beautiful fleece sweater. <small>Made from 100% Canadian wool.</small></p>
                <p><button onclick="addToCart('Fleece Sweater', 44.99)" class="add-to-cart">Add to Cart</button></p>
            </div>
            <div id="product-card-2">
                <img src="images/cat-snow-boots.jpg" alt="Cat Snow Boots">
                <h4 class="productName">Snow Boots</h4>
                <p class="price">$70.99</p>
                <label for="size-2"></label>
                <select id="size-2">
                    <option class="size">Small</option>
                    <option class="size">Medium</option>
                    <option class="size">Large</option>
                </select>
                <p>Keep your cat's feet warm and dry with our Snow Boots. Made from real Canadian leather, Canadian wool, and a recycled rubber sole, these boots are water and stain resistant. <small>Care Instructions: Use a dilute leather cleaner to remove any stains.</small></p>
                <p><button onclick="addToCart('Snow Boots', 70.99)" class="add-to-cart">Add to Cart</button></p>
            </div>
            <div id="product-card-3">
                <img src="images/Frisco-Marled-Sweater.jpg" alt="Cat Marled Sweater">
                <h4 class="productName">Marled Sweater</h4>
                <p class="price">$60.99</p>
                <label for="size-3"></label>
                <select id="size-3">
                    <option class="size">Small</option>
                    <option class="size">Medium</option>
                    <option class="size">Large</option>
                </select>
                <p>Combining handcrafted wool yarn and alpaca yarn, we created one of our softest sweaters</p>
                <button onclick="addToCart('Marled Sweater', 60.99)" class="add-to-cart">Add to Cart</button>
            </div>
        </div>
    </section>
    <section class="custom-services">
        <h3>Custom Creations</h3>
            <p>Kitten Mittons started as custom mittens for friends and family, so we wanted to stay true to our roots and provide everyone with custom products. </p>
            <small>Please note that custom products take longer than our pre-made stock. Depending on the demand for custom works, the wait could be 3-6 weeks excluding shipping time. </small>
            <div class="custom-service-list">
                <ul>
                    <li>Mittens</li>
                    <li>Boots</li>
                    <li>Sweaters</li>
                    <li>Jackets</li>
                    <li>Scarves</li>
                    <li>Hats</li>
                    <li>And More...</li>
                </ul>
            </div>
            <p>To order a custom product, please fill out the Custom Product Form on the Customs page.</p>
    </section>
</main>
<?php
    //global footer
    require 'templates/footer.php';
?>
<!--Non-stock pictures from: https://www.adventurecats.org/gear-safety/do-cats-need-winter-clothing/-->
<!--https://www.adventurecats.org/pawsome-reads/kitty-theres-snow-and-adventure-outside/-->
<!--https://www.rover.com/blog/cool-cat-sweaters/-->