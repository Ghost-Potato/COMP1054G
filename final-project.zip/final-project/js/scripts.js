// //login/signup pop up form
// let loginBtn = document.querySelector("#login-signup-btn");
// let closeLoginBtn = document.querySelector("#close-form-btn")
// //event listener for pop up form
// loginBtn.addEventListener("click", openForm);
// closeLoginBtn.addEventListener("click", closeForm);
// //functions for pop up form
// function openForm() {
//     document.getElementById("login-form").style.display = "block";
// }
//
// function closeForm() {
//     document.getElementById("login-form").style.display = "none";
// }

//ADD TO CART
//variables
//functions
//event listeners



//MOBILE NAVIGATION
//mobile nav variables
let hamburgerBtn = document.getElementById("hamburger-btn")

//mobile nav menu function
function hamburgerMenu() {
    let x = document.getElementById("myLinks");
    //if/else to change display from none to block or vice versa.
    if (x.style.display === "block") {
        x.style.display = "none";
    } else {
        x.style.display = "block";
    }
}

//event listener for hamburger menu
hamburgerBtn.addEventListener("click", hamburgerMenu);


//show password variable
let showBtn = document.getElementById("show-password");

//function to show password
function showPassword() {
    let pass = document.getElementById("password");
    let confirmPass = document.getElementById("confirm-password");
    //if/else to change input type from password to text when the show password button get held down
    if (pass.type === "password") {
        pass.type = "text";
    } else {
        pass.type = "password";
    }
    if (confirmPass.type === "password"){
        confirmPass.type = "text";
    }else{
        confirmPass.type ="password";
    }
}

//event listener for show password
showBtn.addEventListener("click", showPassword);
