// //login/signup pop up form
// let loginBtn = document.querySelector("#login-signup-btn");
// let closeLoginBtn = document.querySelector("#close-form-btn")
// //event listener for pop up form
// loginBtn.addEventListener("click", openForm);
// closeLoginBtn.addEventListener("click", closeForm);
// //functions for pop up form
// function openForm() {
//     document.getElementById("login-form").style.display = "block";
// }
//
// function closeForm() {
//     document.getElementById("login-form").style.display = "none";
// }

//ADD TO CART
//variables
const cart = {};
//functions
function addToCart(productName, price) {
    if (cart[productName]) {
        cart[productName].quantity += 1;
        cart[productName].totalPrice += price;
    } else {
        cart[productName] = {
            quantity: 1,
            totalPrice: price
        };
    }
    updateCartDisplay();
}
function updateCartDisplay() {
    const cartList = document.getElementById('cart');
    cartList.innerHTML = '';
    for (let product in cart) {
        const listItem = document.createElement('li');
        listItem.innerText = `${product} - Quantity: ${cart[product].quantity} - Total Price: CAD${cart[product].totalPrice.toFixed(2)}`;
        cartList.appendChild(listItem);
    }
}

//DISPLAY MESSAGE AFTER SIGNING UP
let submit = document.getElementById("register-btn");
function redirect(messageTimeout){
    //setting a timeout to display the message for a bit
    setTimeout(displayRegisterMessage, 3000);
    //redirecting to main page
    window.location.href = index.php;
}
function displayRegisterMessage(){
    let message = document.getElementById("register-message");
    message.textContent = "Welcome to the Kitten Mitton Club!";
}

//event listener
submit.addEventListener("click", displayRegisterMessage);

//MOBILE NAVIGATION - click on the hamburger and show the nav links. Default: links are hidden.
//mobile nav variables
let hamburgerBtn = document.getElementById("hamburger-btn")

//mobile nav menu function
function hamburgerMenu() {
    let mobileNav = document.getElementById("myLinks");
    //if/else to change display from none to block or vice versa.
    if (mobileNav.style.display === "block") {
        mobileNav.style.display = "none";
    } else {
        mobileNav.style.display = "block";
    }
}

//event listener for hamburger menu
hamburgerBtn.addEventListener("click", hamburgerMenu);

//checkbox to make password visible when creating an account
//show password variable
let showBtn = document.getElementById("show-password");

//function to show password
function showPassword() {
    let pass = document.getElementById("password");
    let confirmPass = document.getElementById("confirm-password");
    //if/else to change input type from password to text when the show password button get held down
    if (pass.type === "password") {
        pass.type = "text";
    } else {
        pass.type = "password";
    }
    if (confirmPass.type === "password"){
        confirmPass.type = "text";
    }else{
        confirmPass.type ="password";
    }
}

//event listener for show password
showBtn.addEventListener("click", showPassword);
