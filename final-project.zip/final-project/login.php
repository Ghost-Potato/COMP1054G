<?php
    //global header
    include 'templates/header.php';
    //title and description variables
    $title = "Kitten Mittens Login";
    $description = "The login page of the Kitten Mittens website";
?>

    <main>
        <section>
            <h2>Welcome Back!</h2>
            <h2>Login</h2>
            <div class="login-form">
                <form action="./templates/validate.php" method="post">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" required>
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required>
                    <button class="submit-popup" type="submit">Submit</button>
                </form>
                <p>Don't have an account? Use the link below to register!</p>
                <a href="register.php">Sign Up</a>
            </div>
        </section>
    </main>

<?php
    //global footer
    include 'templates/footer.php';
?>