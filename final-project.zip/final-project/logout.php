<?php
//global header
include './templates/header.php'; //include fails gracefully
//access existing session
session_start();
//remove session variables
session_unset();
//kill the session
session_destroy();
//redirect to main page
header("location:index.php");
//global footer
include './templates/footer.php';
?>
