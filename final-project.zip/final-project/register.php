<?php
    //global header
    include 'templates/header.php';
    //variables
    $title = "Register";
    $description = "Register a new account";
?>
        <section class="register-section">
            <div>
                <form>
                    <fieldset class="user-info">
                        <label for="firstName"></label>
                        <input type="text" id="firstName" placeholder="First Name">
                        <label for="lastName"></label>
                        <input type="text" id="lastName" placeholder="Last Name">

<!--                        <label for="streetAddress"></label>-->
<!--                        <input type="text" id="streetAddress" placeholder="Address">-->
<!--                        <label for="town"></label>-->
<!--                        <input type="text" id="town" placeholder="Town or City">-->
<!--                        <label for="postal-code"></label>-->
<!--                        <input type="text" id="postal-code" placeholder="Postal Code">-->
<!--                        <label for="province"></label>-->
<!--                        <select id="province">-->
<!--                            <option value="AB">Alberta</option>-->
<!--                            <option value="BC">British Columbia</option>-->
<!--                            <option value="MB">Manitoba</option>-->
<!--                            <option value="NB">New Brunswick</option>-->
<!--                            <option value="NL">Newfoundland and Labrador</option>-->
<!--                            <option value="NS">Nova Scotia</option>-->
<!--                            <option value="NT">Northwest Territories</option>-->
<!--                            <option value="NU">Nunavut</option>-->
<!--                            <option value="ON">Ontario</option>-->
<!--                            <option value="PE">Prince Edward Island</option>-->
<!--                            <option value="QC">Quebec</option>-->
<!--                            <option value="SK">Saskatchewan</option>-->
<!--                            <option value="YT">Yukon</option>-->
<!--                        </select>-->

                    </fieldset>
                    <fieldset class="authentication">
                        <label for="email"></label>
                        <input type="email" id="email" placeholder="Email">
                        <label for="username"></label>
                        <input type="text" id="username" placeholder="Username">
                        <label for="password"></label>
                        <input type="password" id="password" placeholder="Password">
                        <label for="confirm-password"></label>
                        <input type="password" id="confirm-password" placeholder="Confirm Password">
                        <label for="show-password">Show Password</label>
                        <input type="checkbox" id="show-password">
                    </fieldset>
                    <button id=register-btn type="submit">Sign Up</button>
                    <button class="reset-btn" type="reset">Reset</button>
                </form>
            </div>
        </section>
        <!--display message after submit click-->
        <section class="after-register">
            <p id="register-message"></p>
        </section>

<?php
    //global footer
    include 'templates/footer.php';
?>