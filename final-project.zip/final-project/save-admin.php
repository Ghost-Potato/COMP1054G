<?php
//connect to database with require_once
    require_once 'templates/database.php';

//define user variables
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $username = $_POST['username'];
    $confirm_password = $_POST['confirm_password'];

//validate inputs variable
    $input_good = true;

//global header
    include 'templates/header.php';

//checking input: empty, pregmatch, email filter
    //first name
    if (empty($first_name)) {
        $input_good = false;
        echo "First name is required.";
    } elseif (!preg_match("/^[A-Za-zÀ-ÿ '-]+$/", $first_name)) {
        $input_good = false;
        echo "First name must contain letters, spaces, or dashes.";
    }
    //last name
    if(empty($last_name)){
        $input_good = false;
        echo "Last name is required";
    } elseif (!preg_match("/^[A-Za-zÀ-ÿ '-]+$/",$last_name)){
        $input_good = false;
        echo "Last name must contain letters, spaces, or dashes.";
    }
    //email
    if(empty($email)){
        $input_good = false;
        echo "Email is required";
    } elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)){
        $input_good = false;
        echo "Email must be a valid email.";
    }
    //username - 3 to 20 characters, only alphanumeric, underscores, hyphens
    if(empty($username)){
        $input_good = false;
        echo "Username is required";
    } elseif(!preg_match("/^[A-Za-z0-9_-]{3,20}$/",$username)){
        $input_good = false;
        echo "Username must be 3 to 20 characters, contain letters, spaces, or dashes.";
    }
    //password - must be at least 8 characters, contain 1 uppercase, one number, and one special character. Use ?=.* for at least one checks. https://stackoverflow.com/questions/1559751/regex-to-make-sure-that-the-string-contains-at-least-one-lower-case-char-upper
    if(empty($password)){
        $input_good = false;
        echo "Password is required";
    } elseif(!preg_match("/^(?=.*[A-Z])(?=.*\d)(?=.*[`@$!%*?&`])[A-Za-z\d@$!%*?&]{8,}$/",$password)){
        $input_good = false;
        echo "Password must be at least 8 characters in length, contain 1 uppercase letter, 1 number, and one special character (@$!%*?&).";
    }
    if($input_good){
        //hash the password
        $password = hash('sha512', $password);
        //run SQL query to insert into tables
        $sql = "INSERT INTO admins (first_name, last_name, email, username, password) VALUES('$first_name', '$last_name', '$email', '$username', '$password')";
        //connect to db and execute query
        $connection -> exec($sql);
        //message to display after successful save
        echo"<section class='admin-success'>";
        echo "<h3>Admin Succesfully Added!</h3>";
        echo "</section>";
        //close database
        $connection = null;
    }
    ?>