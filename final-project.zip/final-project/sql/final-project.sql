/* regular user sql*/
CREATE TABLE registeredUsers(
    user_id INT NOT NULL AUTO_INCREMENT,
    first_name VARCHAR(75) NOT NULL,
    last_name VARCHAR(75) NOT NULL,
    email VARCHAR(150) NOT NULL,
    username VARCHAR(75) NOT NULL,
    password VARCHAR(75) NOT NULL,
    primary key (user_id)
);

/* admin user sql*/
CREATE TABLE admins(
    admin_id INT NOT NULL AUTO_INCREMENT,
    first_name VARCHAR(75) NOT NULL,
    last_name VARCHAR(75) NOT NULL,
    email VARCHAR(150) NOT NULL,
    username VARCHAR(75) NOT NULL,
    password VARCHAR(75) NOT NULL,
    primary key (admin_id)
);