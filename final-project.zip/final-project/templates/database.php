<?php
//using PDO to connect to database
try{
    $connection = new PDO ('mysql:host=localhost;dbname=php_class', 'root', 'mysql');
    //setting error attribute
    $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}catch(PDOException $e){
    echo "Connection failed: " . $e->getMessage();
}
