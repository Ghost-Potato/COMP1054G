        <footer>
            <div class="footer-logo">
                <a href="index.php"><img src="images/kitten-mitton-logo.png" alt="Kitten Mitton Logo"></a>
            </div>
            <div class="desktop-footer-nav">
                <nav>
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="about.php">About</a></li>
                        <li><a href="register.php">Sign Up</a></li>
                        <li><a href="login.php">Login</a></li>
                    </ul>
                </nav>
            </div>
                <!--font awesome brand icons-->
            <div class="social-media">
                <ul>
                    <li class="fa-brands fa-facebook"></li>
                    <li class="fa-brands fa-instagram"></li>
                    <li class="fa-brands fa-tiktok"></li>
                    <li class="fa-brands fa-youtube"></li>
                </ul>
            </div>
            <div class="payment-options">
                <ul>
                    <li class="fa-brands fa-cc-visa"></li>
                    <li class="fa-brands fa-cc-mastercard"></li>
                    <li class="fa-brands fa-cc-amex"></li>
                    <li class="fa-brands fa-cc-paypal"></li>
                    <li class="fa-brands fa-cc-discover"></li>
                    <li class="fa-brands fa-cc-apple-pay"></li>
                    <li class="fa-brands fa-cc-amazon-pay"></li>
                </ul>
            </div>
            <h6>Final CSS/PHP Project by: Jamie MacDonald</h6>
        </footer>
    </body>
</html>
