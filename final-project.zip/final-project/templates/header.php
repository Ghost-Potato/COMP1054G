<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php echo $description; ?>"
    <meta name="robots" content="noindex, nofollow">
    <!--linking my css-->
    <link rel="stylesheet" href="css/styles.css">
    <!--linking custom fonts-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poiret+One&family=Ysabeau+Office:ital,wght@0,1..1000;1,1..1000&display=swap" rel="stylesheet">
    <!--linking font awesome css-->
    <link rel="stylesheet" href="font-awesome/css/all.css">
    <!--linking my javascript-->
    <script src="js/scripts.js" defer></script>
    <!--linking font awesome javascript-->
    <script src="font-awesome/js/all.js" defer></script>
    <!--title-->
    <title><?php echo $title; ?></title>
</head>
<body>
    <header>
<!--desktop nav-->
        <div class="desktop-nav">
            <nav>
                <ul id="myLinks">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="register.php">Sign Up</a></li>
                </ul>
            </nav>
        </div>
        <div class="shopping-account">
            <button class="shopping-cart-btn">
                <span class="fa-solid fa-bag-shopping"></span>
            </button>
            <!--adding login to user button-->
            <button class="login-signup-btn">
                <a href="login.php"><span class="fa-regular fa-user"></span></a>
            </button>
        </div>
        <div class="logo-container">
            <a href="index.php"><img src="images/kitten-mitton-logo.png" alt="Kitten Mitton Logo"></a>
        </div>
<!--mobile nav-->
        <div class="mobile-nav">
            <button id="hamburger-btn">
        <!--hamburger menu-->
                <span class="fa-solid fa-bars"></span>
            </button>
            <button class="shopping-cart-btn">
                <span class="fa-solid fa-bag-shopping"></span>
            </button>
            <button class="login-signup-btn">
                <a href="login.php"><span class="fa-regular fa-user"></span></a>
            </button>
        </div>
    </header>