<?php
//storing username and password in variables. Using sha512 to hash the password
$username = $_POST['username'];
    $password = hash('sha512', $_POST['password']);
//connect to database with require_once for security
    require_once 'database.php';
//set up and run admin query
    $sql ="SELECT admin_id FROM admins WHERE username = '$username' AND password = '$password'";
    $result = $connection->query($sql); //running the query and storing results
//storing number of results in a variable
$num_result = $result->rowCount();
//check if there are any matches.
if($num_result === 1){ //only want 1 match per id
    echo "Welcome $username";

    // Using fetch to get the user_id and storing it in a session variable.
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    session_start();
    $_SESSION['admin_id'] = $row['admin_id'];

    header('Location: admin-page.php');
    exit; //to stop the script running after redirection
}else{
    echo "Invalid Credentials";
}
//close connection
    $connection = null;